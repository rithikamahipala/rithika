package com.vehiclelicense.vehiclelicense.entity;

public enum ApplicationType {
    LL,
    DL;
}
