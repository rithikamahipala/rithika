package com.vehiclelicense.vehiclelicense.entity;

public enum ApplicationStatus {
	PENDING,
	APPROVED,
	REJECTED;

}
